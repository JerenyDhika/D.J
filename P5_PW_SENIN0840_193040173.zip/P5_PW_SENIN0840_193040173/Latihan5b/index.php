<?php

//menghubungkan dengan file php lainnya
require 'php/function.php';

//melakukan query
$pet = query("SELECT * FROM pet")

?>

<html>

<head>
    <title>index</title>
    <style>
        h5 {
            text-decoration: none;
            color: black;
            font-size: 25px;
        }
    </style>
</head>

<body>

    <table border="1" cellpadding="8" cellspacing="0">

        <tr>
            <th>id</th>
            <th>nama</th>
            <th>kategori</th>
            <th>jenis</th>
            <th>harga</th>
            <th>gambar</th>
        </tr>
        <?php $x = 1; ?>

        <?php foreach ($pet as $y) : ?>
            <tr>
                <td><?php echo $x; ?></td>
                <td><?php echo $y['nama'];  ?></td>
                <td><?php echo $y['kategori'];  ?></td>
                <td><?php echo $y['jenis'];   ?></td>
                <td><?php echo $y['harga']; ?></td>
                <td><img src="assets/Gambar/<?= $e['gambar']; ?>"></td>
            </tr>
            <?php $x++; ?>
        <?php endforeach; ?>

    </table>

    <h5 align="center"></h5>

</body>

</html>