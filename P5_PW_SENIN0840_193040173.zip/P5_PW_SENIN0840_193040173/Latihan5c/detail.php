<?php

// Mengecek apakah ada id yang dikirimkan
// jika tidak maka akan dikembalikan ke halaman index.php
if (!isset($_GET['id'])) {
    header("localtion: ../index.php");
    exit;
}

require 'functions.php';

// Mengambil id dari url
$id = $_GET['id'];

// melakukan query dengan parameter id yang diambil dari url
$y = query("SELECT * FROM alat_musik WHERE id = $id")[0];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latihan5c</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>

        <div class="container">
            <div class="gambar">
                <img src="../assets/img/<?= $y["gambar"]; ?>" alt="">
            </div>
            <div class="keterangan">
                <p><?= $y["nama"]; ?></p>
                <p><?= $y["kategori"]; ?></p>
                <p><?= $y["jenis"]; ?></p>
                <p><?= $y["harga"]; ?></p>
            </div>

            <button class="tombol-kembali"><a href="../index.php" id="tombol">Kembali</a></button>
        </div>

</body>

</html>